# Ahmed & Rana — Bespoke Engagement Invitation

A luxury, mobile-first digital engagement ceremony invitation website crafted with an understated ivory, cream, taupe, and calla-lily aesthetic.

Featuring realistic 3D paper stationery envelope animations, typographic choreography (Parisienne, Cormorant Garamond, Montserrat, Amiri), interactive RSVP with instant visual feedback, Africa/Cairo countdown clock, one-click iCal / Google Calendar generation, Google Maps venue integration, and graceful music playback.

---

## 💍 Event Information

* **Couple:** Ahmed & Rana
* **Occasion:** Engagement Ceremony
* **Date:** Thursday, 24 September 2026
* **Time:** 7:00 PM (Africa/Cairo)
* **Venue:** Levels Cafe, Mansoura, Egypt

---

## 🚀 How to Deploy to Netlify

This website is designed for instant static deployment with zero backend dependencies.

### Option A: Netlify Drop (Drag & Drop — No Git required)

1. Build the production files by running:
   ```bash
   npm run build
   ```
2. Log into [app.netlify.com](https://app.netlify.com).
3. Navigate to **Sites** and locate the **"Want to deploy a new site without connecting to Git? Drag and drop your site folder here"** area.
4. Drag and drop the generated `dist/` directory directly onto Netlify.
5. Your website will be live in seconds with a custom URL and free HTTPS.

### Option B: Git-based Netlify Deployment (Continuous Deployment)

1. Push this repository to GitHub or GitLab.
2. In Netlify, click **"Add new site"** > **"Import an existing project"**.
3. Select your repository.
4. Netlify will automatically detect the settings from `netlify.toml`:
   * **Build command:** `npm run build`
   * **Publish directory:** `dist`
5. Click **Deploy site**. Every future commit will automatically rebuild and deploy.

---

## ⚙️ How to Customize Event Information

All core event data is managed centrally in one file:
`src/config/invitation.ts`

```typescript
export const invitation = {
  groom: "Ahmed",
  bride: "Rana",

  date: "2026-09-24",
  time: "19:00",
  timezone: "Africa/Cairo",

  venue: "Levels Cafe",
  city: "Mansoura",
  country: "Egypt",

  mapQuery: "Levels Cafe, Mansoura, Egypt"
};
```

### 1. Changing Names
Update the `groom` and `bride` properties in `src/config/invitation.ts`. The script typography will automatically re-render the names across the envelope, announcement, card, and signature.

### 2. Changing Event Date & Time
* Update `date` (format: `YYYY-MM-DD`) and `time` (format: `HH:mm`) in `src/config/invitation.ts`.
* The countdown timer and `.ics` calendar invitation generator will automatically update to reflect the new date and start time.

### 3. Changing the Venue & City
* Change `venue`, `city`, and `country` in `src/config/invitation.ts`.

### 4. Updating Google Maps Location
* Modify `mapQuery` in `src/config/invitation.ts` (e.g. `"Levels Cafe, Mansoura, Egypt"` or any Google Maps search query or Plus Code). The **"View Location"** button will automatically open a search targeting that exact spot.

### 5. Replacing Floral Artwork (Calla Lilies)
* The calla lily motifs are lightweight, scalable vector SVGs in `src/components/CallaLily.tsx`.
* You can adjust colors (petals, spadix, stem) or scale directly in that component, or swap in custom SVG files inside `public/assets/flowers/`.

### 6. Replacing Social Preview Artwork (OpenGraph / WhatsApp / iMessage)
* The social card preview is located at:
  `public/assets/social/og-preview.png`
* To customize, edit the source vector in `public/assets/social/og-preview.svg` or drop your own 1200x630 PNG into `public/assets/social/og-preview.png`.

---

## 🎨 Typography & Design System

* **Script Display:** `Parisienne` (Ahmed & Rana)
* **Serif Headings & Quotes:** `Cormorant Garamond`
* **Labels & Buttons:** `Montserrat` (letterspaced uppercase)
* **Arabic Phrase:** `Amiri`
* **Color Palette:**
  * Warm Ivory: `#FBF9F5`
  * Soft Cream: `#F5EFEB`
  * Stationery Taupe: `#8A7E72` / `#C7BCAD`
  * Deep Stone: `#3D362F`
  * Champagne Gold: `#B8996C`
  * Pale Sage: `#939F8C`

---

## 📱 Mobile-First Quality Checklist

- [x] Responsive on small (320px) to large (1440px+) displays
- [x] Safe area insets supported for modern mobile navigation bars
- [x] Touch targets exceed 44px for effortless tapping
- [x] Keyboard and screen-reader accessibility (`aria-label`, semantic tags)
- [x] Reduced motion preference handled gracefully (`prefers-reduced-motion: reduce`)
