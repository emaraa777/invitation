import React from 'react';
import { invitation } from '../config/invitation';
import { CallaLily } from './CallaLily';

export const PersonalMessage: React.FC = () => {
  return (
    <section id="personal-message-section" className="w-full max-w-lg mx-auto px-6 py-20 text-center relative">
      <div className="flex flex-col items-center justify-center">
        {/* Quote text with Cormorant Garamond */}
        <blockquote className="font-serif-cormorant italic text-2xl sm:text-3xl md:text-4xl text-[#3A332C] leading-relaxed max-w-md font-light">
          “We would be honoured to share
          <br />
          this special day with you.”
        </blockquote>

        {/* Calla lily accent beside the signature */}
        <div className="my-6 flex items-center justify-center gap-4">
          <div className="w-8 h-px bg-[#B8996C]/40" />
          <CallaLily width={36} height={54} animate={false} />
          <div className="w-8 h-px bg-[#B8996C]/40" />
        </div>

        {/* Names */}
        <p className="font-script text-3xl sm:text-4xl text-[#2E2822]">
          {invitation.groom} & {invitation.bride}
        </p>
      </div>
    </section>
  );
};
