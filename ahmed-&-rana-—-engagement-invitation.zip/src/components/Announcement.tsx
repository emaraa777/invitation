import React from 'react';
import { invitation } from '../config/invitation';
import { CallaLily } from './CallaLily';

interface AnnouncementProps {
  isVisible: boolean;
}

export const Announcement: React.FC<AnnouncementProps> = ({ isVisible }) => {
  return (
    <section
      id="announcement-section"
      className={`w-full max-w-xl mx-auto text-center px-4 pt-12 pb-16 transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'
      }`}
    >
      {/* 1. Opening Arabic Phrase: بسم الله الرحمن الرحيم */}
      <div className="mb-8">
        <p
          className="font-arabic-amiri text-2xl sm:text-3xl text-[#5A5046] tracking-wide leading-relaxed select-none"
          dir="rtl"
        >
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </p>
        <div className="w-12 h-px bg-[#B8996C]/40 mx-auto mt-4" />
      </div>

      {/* Minimal calla lily accent with delicate sway */}
      <div className="my-6 flex justify-center">
        <CallaLily width={50} height={75} animate={true} />
      </div>

      {/* 2. Intro Wording */}
      <p className="text-[11px] sm:text-xs tracking-[0.28em] uppercase text-[#7D7164] font-sans-montserrat font-medium mb-8">
        Together with their families
      </p>

      {/* 3. The Names (Strongest Typographic Moment with Staggered Fade) */}
      <div className="my-6 flex flex-col items-center justify-center space-y-1">
        {/* Groom: Ahmed */}
        <h1
          className="font-script text-6xl sm:text-7xl md:text-8xl text-[#2E2822] leading-[1.1] transition-all duration-700"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(16px)',
            transitionDelay: '150ms',
          }}
        >
          {invitation.groom}
        </h1>

        {/* Ampersand: & */}
        <span
          className="font-serif-cormorant italic text-3xl sm:text-4xl text-[#B8996C] select-none my-1 transition-all duration-700"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(16px)',
            transitionDelay: '350ms',
          }}
        >
          &
        </span>

        {/* Bride: Rana */}
        <h1
          className="font-script text-6xl sm:text-7xl md:text-8xl text-[#2E2822] leading-[1.1] transition-all duration-700"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(16px)',
            transitionDelay: '550ms',
          }}
        >
          {invitation.bride}
        </h1>
      </div>

      {/* 4. Event Announcement */}
      <div className="mt-8 space-y-2">
        <p className="text-[11px] sm:text-xs tracking-[0.25em] uppercase text-[#7D7164] font-sans-montserrat font-medium">
          Invite you to join their
        </p>
        <h2 className="font-serif-cormorant text-2xl sm:text-3xl text-[#3D362F] font-light tracking-wide">
          Engagement Ceremony
        </h2>
      </div>

      {/* Subtle Divider */}
      <div className="mt-12 flex items-center justify-center gap-3">
        <span className="w-10 h-px bg-[#D6CABE]" />
        <span className="w-1.5 h-1.5 rounded-full bg-[#B8996C]" />
        <span className="w-10 h-px bg-[#D6CABE]" />
      </div>
    </section>
  );
};
