import React from 'react';

interface CallaLilyProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  animate?: boolean;
  flipped?: boolean;
}

/**
 * Bespoke Calla Lily SVG vector illustration:
 * Features a pure ivory funnel petal, warm cream inner shading,
 * subtle champagne spadix, and slender sage stem.
 */
export const CallaLily: React.FC<CallaLilyProps> = ({
  className = '',
  width = 64,
  height = 96,
  animate = false,
  flipped = false,
}) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 100 150"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${animate ? 'animate-delicate-sway' : ''} ${className} pointer-events-none select-none`}
      style={{
        transform: flipped ? 'scaleX(-1)' : undefined,
      }}
      aria-hidden="true"
    >
      <defs>
        {/* Soft cream petal gradient */}
        <linearGradient id="callaPetalGrad" x1="20" y1="10" x2="80" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="45%" stopColor="#FAF7F2" />
          <stop offset="85%" stopColor="#EFE8DD" />
          <stop offset="100%" stopColor="#E2D7C7" />
        </linearGradient>

        {/* Petal shadow fold */}
        <linearGradient id="callaShadowGrad" x1="45" y1="30" x2="60" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#D9CEBF" stopOpacity="0.8" />
          <stop offset="70%" stopColor="#CBBFA9" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#FAF7F2" stopOpacity="0" />
        </linearGradient>

        {/* Champagne gold spadix gradient */}
        <linearGradient id="callaSpadixGrad" x1="48" y1="20" x2="55" y2="55" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#D9BD8B" />
          <stop offset="50%" stopColor="#C7A56D" />
          <stop offset="100%" stopColor="#A88752" />
        </linearGradient>

        {/* Soft sage stem gradient */}
        <linearGradient id="callaStemGrad" x1="50" y1="70" x2="54" y2="150" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#9EAA95" />
          <stop offset="50%" stopColor="#8A9881" />
          <stop offset="100%" stopColor="#75826D" />
        </linearGradient>
      </defs>

      {/* Slender stem */}
      <path
        d="M50 78 C51 100, 52 125, 49 148"
        stroke="url(#callaStemGrad)"
        strokeWidth="3.2"
        strokeLinecap="round"
      />

      {/* Spadix (golden spadix core) */}
      <path
        d="M48 38 C49 31, 51 25, 53 23 C54.5 24, 53 32, 50 48 Z"
        fill="url(#callaSpadixGrad)"
      />

      {/* Back petal curve */}
      <path
        d="M32 45 C28 30, 42 12, 55 12 C68 12, 75 25, 68 45 C64 53, 56 65, 50 78 C44 65, 36 53, 32 45 Z"
        fill="url(#callaPetalGrad)"
      />

      {/* Inner petal overlap & fold */}
      <path
        d="M40 38 C46 28, 56 22, 60 27 C64 32, 58 46, 50 78 C46 64, 38 52, 40 38 Z"
        fill="url(#callaShadowGrad)"
      />

      {/* Front wrapping petal lip with elegant calla tip */}
      <path
        d="M26 40 C34 32, 44 40, 50 78 C55 42, 68 34, 76 42 C68 62, 58 75, 50 82 C42 75, 32 62, 26 40 Z"
        fill="#FCFAF7"
        stroke="#E8DFD3"
        strokeWidth="0.8"
      />

      {/* Delicate calla lily tip curl */}
      <path
        d="M55 12 C57 9, 61 7, 63 8 C62 10, 58 12, 55 12 Z"
        fill="#EFE8DE"
      />
    </svg>
  );
};
