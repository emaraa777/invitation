import React, { useState } from 'react';
import { invitation } from '../config/invitation';
import { RsvpChoice } from '../types';

export const RsvpSection: React.FC = () => {
  const [selectedChoice, setSelectedChoice] = useState<RsvpChoice>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);

  const handleChoice = (choice: 'attending_white_heart' | 'attending_smirk') => {
    if (selectedChoice || isTransitioning || isConfirmed) return;

    // Trigger subtle haptic feedback on supported mobile devices
    try {
      if (typeof window !== 'undefined' && 'navigator' in window && typeof window.navigator.vibrate === 'function') {
        // A gentle, tactile confirmation pattern (two brief, subtle 30ms pulses)
        window.navigator.vibrate([30, 40, 30]);
      }
    } catch {
      // Gracefully ignore if vibration is restricted or unsupported
    }

    setSelectedChoice(choice);
    setIsTransitioning(true);

    // 1. Button presses, then 400ms: question and buttons fade out & translateY(-8px)
    setTimeout(() => {
      // 5. Remove original question from layout & show confirmation
      setIsConfirmed(true);
      setIsTransitioning(false);
    }, 450);
  };

  return (
    <section id="rsvp-section" className="w-full max-w-lg mx-auto px-4 py-16 text-center min-h-[260px] flex items-center justify-center">
      {!isConfirmed ? (
        /* QUESTION STATE */
        <div
          className={`w-full transition-all duration-400 ease-out ${
            isTransitioning ? 'opacity-0 -translate-y-2 pointer-events-none' : 'opacity-100 translate-y-0'
          }`}
        >
          {/* "One last question…" */}
          <p className="text-[11px] sm:text-xs tracking-[0.26em] uppercase text-[#8A7E72] font-sans-montserrat font-medium mb-3">
            One last question…
          </p>

          {/* "Will you celebrate with us?" */}
          <h3 className="font-serif-cormorant text-3xl sm:text-4xl text-[#2E2822] font-normal mb-8">
            Will you celebrate with us?
          </h3>

          {/* Two positive attending buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-md mx-auto">
            <button
              id="rsvp-choice-absolutely"
              type="button"
              onClick={() => handleChoice('attending_white_heart')}
              className={`w-full sm:w-auto px-6 py-3.5 rounded-full border border-[#C5B8AA] bg-[#FFFDF9] text-[#3D362F] text-xs font-sans-montserrat tracking-[0.14em] font-medium shadow-2xs hover:bg-[#FAF5EF] hover:border-[#9E9080] hover:-translate-y-0.5 active:scale-98 transition-all duration-200 cursor-pointer ${
                selectedChoice === 'attending_white_heart' ? 'scale-98 bg-[#F0EAE1]' : ''
              }`}
            >
              Absolutely, I’ll be there 🤍
            </button>

            <button
              id="rsvp-choice-dare"
              type="button"
              onClick={() => handleChoice('attending_smirk')}
              className={`w-full sm:w-auto px-6 py-3.5 rounded-full border border-[#C5B8AA] bg-[#FFFDF9] text-[#3D362F] text-xs font-sans-montserrat tracking-[0.14em] font-medium shadow-2xs hover:bg-[#FAF5EF] hover:border-[#9E9080] hover:-translate-y-0.5 active:scale-98 transition-all duration-200 cursor-pointer ${
                selectedChoice === 'attending_smirk' ? 'scale-98 bg-[#F0EAE1]' : ''
              }`}
            >
              Wouldn’t dare miss it 😏
            </button>
          </div>
        </div>
      ) : (
        /* CONFIRMATION STATE (Completely replaces the question layout) */
        <div className="w-full relative px-6 py-8 rounded-2xl bg-[#FFFDF9] border border-[#E7DDD0] shadow-sm animate-[fadeIn_600ms_cubic-bezier(0.22,1,0.36,1)_forwards]">
          {/* 4 Tiny delicate gold sparkles that appear once and disappear */}
          <div className="absolute top-4 left-6 text-[#B8996C] text-sm animate-sparkle" style={{ animationDelay: '100ms' }}>
            ✦
          </div>
          <div className="absolute top-6 right-8 text-[#B8996C] text-xs animate-sparkle" style={{ animationDelay: '250ms' }}>
            ✧
          </div>
          <div className="absolute bottom-6 left-12 text-[#B8996C] text-xs animate-sparkle" style={{ animationDelay: '400ms' }}>
            ✧
          </div>
          <div className="absolute bottom-4 right-10 text-[#B8996C] text-sm animate-sparkle" style={{ animationDelay: '300ms' }}>
            ✦
          </div>

          {/* Exact Confirmation Text as requested */}
          <div className="space-y-4">
            <p className="font-serif-cormorant text-2xl sm:text-3xl text-[#2E2822] leading-relaxed font-light">
              We can’t wait to celebrate
              <br />
              this beautiful moment with you.
            </p>

            <p className="font-serif-cormorant italic text-lg sm:text-xl text-[#7D7063]">
              See you on September 24th ✨
            </p>

            <div className="pt-3">
              <p className="font-script text-2xl sm:text-3xl text-[#3D362F]">
                {invitation.groom} & {invitation.bride}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
