import React, { useState, useEffect } from 'react';
import { invitation } from '../config/invitation';

interface EnvelopeProps {
  onOpenComplete: () => void;
}

export const Envelope: React.FC<EnvelopeProps> = ({ onOpenComplete }) => {
  const [isAssetsReady, setIsAssetsReady] = useState(false);
  const [animationStep, setAnimationStep] = useState<
    'closed' | 'opening-flap' | 'rising-card' | 'expanded'
  >('closed');
  const [buttonFading, setButtonFading] = useState(false);

  useEffect(() => {
    let isMounted = true;

    // Ensure all custom fonts (Parisienne, Cormorant Garamond, Montserrat, Amiri)
    // are completely loaded before allowing the envelope to open, preventing layout shift or font swap flashes.
    const prepareAssets = async () => {
      try {
        if ('fonts' in document) {
          await document.fonts.ready;
        }
      } catch (err) {
        // Graceful fallback if font API encounters an issue
      } finally {
        if (isMounted) {
          // Small aesthetic stabilization tick for smooth paint
          setTimeout(() => {
            if (isMounted) setIsAssetsReady(true);
          }, 350);
        }
      }
    };

    prepareAssets();

    // Safety fallback: ensure ready within 1200ms regardless of network state
    const fallbackTimer = setTimeout(() => {
      if (isMounted) setIsAssetsReady(true);
    }, 1200);

    return () => {
      isMounted = false;
      clearTimeout(fallbackTimer);
    };
  }, []);

  const handleOpenClick = () => {
    if (!isAssetsReady || animationStep !== 'closed') return;

    // Optional gentle haptic click when opening envelope
    try {
      if (typeof window !== 'undefined' && 'navigator' in window && typeof window.navigator.vibrate === 'function') {
        window.navigator.vibrate(25);
      }
    } catch {
      // Ignore
    }

    // 0ms: Button begins fading
    setButtonFading(true);

    // 100ms: Envelope gently rises 5px & 150ms: Top flap begins opening
    setTimeout(() => {
      setAnimationStep('opening-flap');
    }, 120);

    // 550ms: Card starts rising while flap finishes
    setTimeout(() => {
      setAnimationStep('rising-card');
    }, 550);

    // 1350ms: Invitation content takes over
    setTimeout(() => {
      setAnimationStep('expanded');
      onOpenComplete();
    }, 1350);
  };

  const isFlapOpen = animationStep !== 'closed';
  const isCardRising = animationStep === 'rising-card' || animationStep === 'expanded';

  return (
    <div className="w-full max-w-sm sm:max-w-md mx-auto flex flex-col items-center">
      {/* 3D Perspective Scene Container */}
      <div
        className="envelope-3d-scene relative w-full aspect-[1.55/1] max-w-[380px] sm:max-w-[420px] transition-transform duration-700 ease-out"
        style={{
          transform: isFlapOpen ? 'translate3d(0, -5px, 0)' : 'translate3d(0, 0, 0)',
        }}
      >
        {/* Understated Envelope Shadow */}
        <div
          className="absolute -bottom-4 inset-x-8 h-8 rounded-full pointer-events-none transition-opacity duration-700"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(61, 54, 47, 0.16) 0%, rgba(61, 54, 47, 0) 70%)',
            opacity: animationStep === 'expanded' ? 0.4 : 0.8,
          }}
        />

        {/* 1. BACK ENVELOPE BODY (Interior pocket lining) */}
        <div className="absolute inset-0 rounded-lg overflow-hidden bg-[#C9BEAF] shadow-sm border border-[#BAAE9E]/60">
          {/* Subtle interior liner with warm cream tone */}
          <div className="absolute inset-1.5 rounded-md bg-gradient-to-b from-[#EFE8DD] to-[#E3D8C8] shadow-inner" />
        </div>

        {/* 2. INVITATION CARD (Nested inside envelope) */}
        <div
          id="nested-invitation-card"
          className="absolute inset-x-5 h-[90%] bottom-3 rounded-md bg-[#FFFDF9] shadow-md border border-[#E5DACD] transition-all duration-700"
          style={{
            transform: isCardRising
              ? 'translate3d(0, -92%, 0) scale(1.02)'
              : 'translate3d(0, 3px, 0)',
            transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
            transitionDuration: isCardRising ? '750ms' : '400ms',
            zIndex: isCardRising ? 25 : 10,
          }}
        >
          {/* Card subtle border accent & gold foil header line */}
          <div className="h-full w-full p-4 flex flex-col items-center justify-between border border-[#B8996C]/25 rounded-sm relative overflow-hidden">
            {/* Top gold corner motifs */}
            <div className="w-full flex justify-between items-center pt-1 px-1">
              <span className="w-3 h-px bg-[#B8996C]/40" />
              <p className="text-[9px] tracking-[0.22em] text-[#8A7E72] font-sans-montserrat uppercase">
                Engagement
              </p>
              <span className="w-3 h-px bg-[#B8996C]/40" />
            </div>

            {/* Card Names */}
            <div className="text-center py-2">
              <h3 className="font-script text-2xl sm:text-3xl text-[#3D362F] leading-tight">
                {invitation.groom} & {invitation.bride}
              </h3>
              <p className="text-[10px] tracking-[0.18em] text-[#6E645A] font-serif-cormorant italic mt-0.5">
                24 · September · 2026
              </p>
            </div>

            {/* Bottom accent */}
            <div className="pb-1 text-[8px] tracking-[0.2em] uppercase text-[#9E9285] font-sans-montserrat">
              Levels Cafe · Mansoura
            </div>
          </div>
        </div>

        {/* 3. FRONT POCKET (Realistic overlapping stationery flaps) */}
        <div className="absolute inset-0 pointer-events-none z-20">
          <svg
            viewBox="0 0 420 270"
            className="w-full h-full filter drop-shadow(0 -1px 3px rgba(60,50,40,0.08))"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="frontPocketGrad" x1="210" y1="90" x2="210" y2="270" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#C4B9AA" />
                <stop offset="60%" stopColor="#BEB2A3" />
                <stop offset="100%" stopColor="#B3A696" />
              </linearGradient>
              <linearGradient id="sideFlapLeft" x1="0" y1="135" x2="160" y2="135" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#C2B6A7" />
                <stop offset="100%" stopColor="#B5A999" />
              </linearGradient>
              <linearGradient id="sideFlapRight" x1="420" y1="135" x2="260" y2="135" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#C2B6A7" />
                <stop offset="100%" stopColor="#B5A999" />
              </linearGradient>
            </defs>

            {/* Left triangular side flap */}
            <path
              d="M0 0 L165 145 L0 270 Z"
              fill="url(#sideFlapLeft)"
              opacity="0.95"
            />

            {/* Right triangular side flap */}
            <path
              d="M420 0 L255 145 L420 270 Z"
              fill="url(#sideFlapRight)"
              opacity="0.95"
            />

            {/* Bottom pocket flap with soft curved V apex */}
            <path
              d="M0 270 L175 142 C198 126, 222 126, 245 142 L420 270 Z"
              fill="url(#frontPocketGrad)"
              stroke="#A89A89"
              strokeWidth="0.75"
            />

            {/* Subtle soft rim highlight on the pocket edge */}
            <path
              d="M0 270 L175 142 C198 126, 222 126, 245 142 L420 270"
              stroke="rgba(255, 255, 255, 0.4)"
              strokeWidth="0.8"
            />
          </svg>
        </div>

        {/* 4. TOP FLAP (With realistic 3D rotateX and transform-origin) */}
        <div
          className="envelope-flap absolute inset-x-0 top-0 h-[56%] z-30"
          style={{
            transform: isFlapOpen ? 'rotateX(180deg)' : 'rotateX(0deg)',
            zIndex: isFlapOpen ? 5 : 30,
          }}
        >
          <svg
            viewBox="0 0 420 152"
            className="w-full h-full filter drop-shadow(0 4px 6px rgba(50,42,35,0.12))"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="topFlapGrad" x1="210" y1="0" x2="210" y2="152" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#CABFB1" />
                <stop offset="85%" stopColor="#BAAE9D" />
                <stop offset="100%" stopColor="#B2A594" />
              </linearGradient>
            </defs>

            {/* Smooth triangular top flap folding downward */}
            <path
              d="M0 0 L188 138 C202 148, 218 148, 232 138 L420 0 Z"
              fill="url(#topFlapGrad)"
              stroke="#A39684"
              strokeWidth="0.75"
            />
            {/* Top flap soft light rim */}
            <path
              d="M0 0 L188 138 C202 148, 218 148, 232 138 L420 0"
              stroke="rgba(255, 255, 255, 0.35)"
              strokeWidth="0.8"
            />
          </svg>

          {/* 5. TINY SUBTLE MONOGRAM WAX SEAL */}
          <div
            className="absolute left-1/2 bottom-[-16px] -translate-x-1/2 w-9 h-9 rounded-full flex items-center justify-center shadow-md transition-opacity duration-300"
            style={{
              background: 'radial-gradient(circle at 35% 35%, #AB9987 0%, #8E7C6A 65%, #6B5B4C 100%)',
              border: '1px solid rgba(255,255,255,0.25)',
              boxShadow: '0 2px 6px rgba(55,46,38,0.3)',
              opacity: isFlapOpen ? 0.7 : 1,
            }}
          >
            <span className="font-serif-cormorant font-semibold text-[11px] text-[#F9F5EC] tracking-wider drop-shadow-sm select-none">
              A&R
            </span>
          </div>
        </div>
      </div>

      {/* Button & Loading Container with fixed reserved height to eliminate Cumulative Layout Shift (CLS) */}
      <div className="mt-8 text-center h-16 flex items-center justify-center relative w-full max-w-xs">
        {animationStep === 'closed' && (
          <>
            {/* Subtle Loading State */}
            {!isAssetsReady ? (
              <div
                id="envelope-loading-state"
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-full bg-[#F3ECE1]/60 border border-[#DDD3C6] text-[#8A7E72] text-[11px] tracking-[0.22em] font-sans-montserrat uppercase transition-opacity duration-400"
                aria-live="polite"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-[#B8996C] animate-pulse" />
                <span>Preparing invitation…</span>
              </div>
            ) : (
              /* Active Action Button (fades in smoothly with zero layout movement) */
              <button
                id="open-invitation-btn"
                type="button"
                onClick={handleOpenClick}
                disabled={buttonFading}
                className={`cursor-pointer px-8 py-3.5 rounded-full bg-[#3D362F] text-[#FBF9F5] text-[13px] tracking-[0.2em] font-sans-montserrat uppercase shadow-sm border border-[#544B42] hover:bg-[#2C2621] hover:-translate-y-0.5 active:scale-98 transition-all duration-300 ${
                  buttonFading
                    ? 'opacity-0 scale-95 pointer-events-none'
                    : 'opacity-100 scale-100'
                }`}
                aria-label="Open wedding engagement invitation"
              >
                Open Invitation <span className="ml-1 text-sm">💍</span>
              </button>
            )}
          </>
        )}

        {animationStep !== 'closed' && (
          <p className="text-xs tracking-[0.2em] uppercase font-sans-montserrat text-[#8A7E72] animate-pulse">
            Unfolding our special moment…
          </p>
        )}
      </div>
    </div>
  );
};
