import React, { useEffect, useState } from 'react';
import { CountdownTime } from '../types';

interface TimeUnitProps {
  label: string;
  value: number;
}

const TimeUnit: React.FC<TimeUnitProps> = ({ label, value }) => {
  const formatted = String(value).padStart(2, '0');
  const [displayValue, setDisplayValue] = useState(formatted);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    if (formatted !== displayValue) {
      setAnimating(true);
      const timer = setTimeout(() => {
        setDisplayValue(formatted);
        setAnimating(false);
      }, 180);
      return () => clearTimeout(timer);
    }
  }, [formatted, displayValue]);

  return (
    <div className="flex flex-col items-center">
      {/* Compact warm ivory card */}
      <div className="w-16 sm:w-20 h-16 sm:h-20 bg-[#FFFDF9] rounded-xl border border-[#E2D8CC] shadow-[0_2px_8px_rgba(61,54,47,0.04)] flex items-center justify-center relative overflow-hidden">
        <span
          className={`font-serif-cormorant text-3xl sm:text-4xl text-[#332C25] font-normal transition-all duration-200 ${
            animating
              ? 'opacity-0 translate-y-1 scale-95'
              : 'opacity-100 translate-y-0 scale-100'
          }`}
        >
          {displayValue}
        </span>
      </div>
      {/* Uppercase tiny label */}
      <span className="mt-2 text-[9px] sm:text-[10px] tracking-[0.2em] uppercase font-sans-montserrat text-[#8A7E72] font-medium">
        {label}
      </span>
    </div>
  );
};

export const Countdown: React.FC = () => {
  // Target: 24 September 2026, 19:00 Cairo Time (UTC+3)
  const targetTime = new Date('2026-09-24T19:00:00+03:00').getTime();

  const calculateTimeLeft = (): CountdownTime => {
    const now = Date.now();
    const difference = targetTime - now;

    if (difference <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
    }

    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((difference / 1000 / 60) % 60);
    const seconds = Math.floor((difference / 1000) % 60);

    return { days, hours, minutes, seconds, isPast: false };
  };

  const [timeLeft, setTimeLeft] = useState<CountdownTime>(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section id="countdown-section" className="w-full max-w-lg mx-auto px-4 py-12 text-center">
      {/* Heading */}
      <p className="font-serif-cormorant italic text-xl sm:text-2xl text-[#52483E] mb-6">
        Counting down to our special day
      </p>

      {/* 4 Compact Timer Units */}
      <div className="flex items-center justify-center gap-2.5 sm:gap-4">
        <TimeUnit label="Days" value={timeLeft.days} />
        <span className="font-serif-cormorant text-xl text-[#B8996C] mb-6 select-none">:</span>
        <TimeUnit label="Hours" value={timeLeft.hours} />
        <span className="font-serif-cormorant text-xl text-[#B8996C] mb-6 select-none">:</span>
        <TimeUnit label="Minutes" value={timeLeft.minutes} />
        <span className="font-serif-cormorant text-xl text-[#B8996C] mb-6 select-none">:</span>
        <TimeUnit label="Seconds" value={timeLeft.seconds} />
      </div>
    </section>
  );
};
