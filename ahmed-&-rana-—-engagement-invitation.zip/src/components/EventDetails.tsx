import React, { useEffect, useRef, useState } from 'react';
import { MapPin, Clock, Calendar as CalendarIcon } from 'lucide-react';
import { invitation } from '../config/invitation';

export const EventDetails: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setInView(true);
            observer.disconnect(); // Animate only once
          }
        });
      },
      { threshold: 0.25 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    invitation.mapQuery
  )}`;

  return (
    <section
      id="event-details"
      ref={containerRef}
      className="w-full max-w-lg mx-auto px-4 py-12 text-center"
    >
      {/* Date Container with subtle card border and warm ivory fill */}
      <div className="bg-[#FFFDF9] rounded-2xl p-8 sm:p-10 border border-[#E8DFD3] shadow-sm relative overflow-hidden">
        {/* Soft corner accents */}
        <div className="absolute top-3 left-3 w-3 h-3 border-t border-l border-[#B8996C]/30" />
        <div className="absolute top-3 right-3 w-3 h-3 border-t border-r border-[#B8996C]/30" />
        <div className="absolute bottom-3 left-3 w-3 h-3 border-b border-l border-[#B8996C]/30" />
        <div className="absolute bottom-3 right-3 w-3 h-3 border-b border-r border-[#B8996C]/30" />

        {/* THURSDAY */}
        <p
          className="text-xs sm:text-sm tracking-[0.3em] uppercase text-[#7D7164] font-sans-montserrat font-medium transition-all duration-500 ease-out"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? 'translateY(0)' : 'translateY(12px)',
          }}
        >
          Thursday
        </p>

        {/* 24 (The Largest Element, with gentle scale 0.94 -> 1) */}
        <div
          className="my-3 transition-all duration-600 ease-out"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? 'scale(1)' : 'scale(0.94)',
            transitionDelay: '180ms',
          }}
        >
          <span className="font-serif-cormorant text-7xl sm:text-8xl md:text-9xl text-[#2E2822] font-normal tracking-tight block select-none">
            24
          </span>
        </div>

        {/* SEPTEMBER 2026 */}
        <div
          className="transition-all duration-500 ease-out"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? 'translateY(0)' : 'translateY(8px)',
            transitionDelay: '420ms',
          }}
        >
          <p className="font-serif-cormorant text-xl sm:text-2xl tracking-[0.2em] uppercase text-[#52483E] font-medium">
            September 2026
          </p>
        </div>

        {/* 7:00 PM */}
        <div
          className="mt-4 inline-flex items-center justify-center gap-2 py-1.5 px-4 rounded-full bg-[#F6F1EA] border border-[#E0D5C7] text-[#63574A] transition-all duration-500 ease-out"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? 'translateY(0)' : 'translateY(8px)',
            transitionDelay: '650ms',
          }}
        >
          <Clock className="w-3.5 h-3.5 text-[#B8996C]" />
          <span className="font-sans-montserrat text-xs tracking-[0.18em] font-medium uppercase">
            7:00 PM · Cairo Time
          </span>
        </div>
      </div>

      {/* VENUE SECTION */}
      <div className="mt-12">
        <p className="text-[10px] tracking-[0.28em] uppercase text-[#8A7E72] font-sans-montserrat font-semibold mb-2">
          Venue
        </p>

        <h3 className="font-serif-cormorant text-3xl sm:text-4xl text-[#2E2822] font-medium tracking-wide">
          {invitation.venue}
        </h3>

        <div className="mt-2 flex items-center justify-center gap-1.5 text-[#6E6356]">
          <MapPin className="w-4 h-4 text-[#B8996C] shrink-0" />
          <p className="font-sans-montserrat text-xs sm:text-sm tracking-wider uppercase font-light">
            {invitation.city}, {invitation.country}
          </p>
        </div>

        {/* View Location Link / Button */}
        <div className="mt-5">
          <a
            id="view-location-btn"
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full border border-[#9E9080] text-[#3D362F] hover:bg-[#3D362F] hover:text-[#FBF9F5] text-xs font-sans-montserrat tracking-[0.16em] uppercase transition-all duration-200 hover:-translate-y-0.5 active:scale-98"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>View Location</span>
          </a>
        </div>
      </div>
    </section>
  );
};
