import React from 'react';
import { Calendar, Download } from 'lucide-react';
import { invitation } from '../config/invitation';

export const CalendarAction: React.FC = () => {
  const downloadIcs = () => {
    // 24 September 2026, 19:00 Africa/Cairo (UTC+3) -> 16:00:00Z
    // 4 hours duration -> 23:00 Africa/Cairo -> 20:00:00Z
    const icsData = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Ahmed & Rana//Engagement Invitation//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      'BEGIN:VEVENT',
      'UID:ahmed-rana-engagement-20260924@invitation',
      'DTSTAMP:20260915T000000Z',
      'DTSTART:20260924T160000Z',
      'DTEND:20260924T200000Z',
      `SUMMARY:${invitation.groom} & ${invitation.bride} — Engagement Ceremony`,
      'DESCRIPTION:Ahmed & Rana invite you to celebrate their engagement.',
      `LOCATION:${invitation.venue}, ${invitation.city}, ${invitation.country}`,
      'STATUS:CONFIRMED',
      'SEQUENCE:0',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', 'ahmed-and-rana-engagement.ics');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Google Calendar URL (Direct 1-click web calendar add)
  const googleCalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
    `${invitation.groom} & ${invitation.bride} — Engagement Ceremony`
  )}&dates=20260924T160000Z/20260924T200000Z&details=${encodeURIComponent(
    'Ahmed & Rana invite you to celebrate their engagement.'
  )}&location=${encodeURIComponent(
    `${invitation.venue}, ${invitation.city}, ${invitation.country}`
  )}`;

  return (
    <div className="w-full max-w-sm mx-auto my-6 px-4 flex flex-col sm:flex-row items-center justify-center gap-3">
      {/* Primary .ics download button */}
      <button
        id="add-to-calendar-btn"
        type="button"
        onClick={downloadIcs}
        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-[#FAF6F0] border border-[#C7BBAE] text-[#4A4138] hover:bg-[#3D362F] hover:text-[#FBF9F5] hover:border-[#3D362F] text-xs font-sans-montserrat tracking-[0.16em] uppercase transition-all duration-200 hover:-translate-y-0.5 active:scale-98 cursor-pointer shadow-xs"
        aria-label="Add event to calendar via iCal download"
      >
        <Calendar className="w-3.5 h-3.5 text-[#B8996C]" />
        <span>Add to Calendar (.ics)</span>
      </button>

      {/* Google Calendar 1-Click option */}
      <a
        id="add-to-google-cal-btn"
        href={googleCalUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full border border-transparent text-[#7A6E62] hover:text-[#3D362F] text-xs font-sans-montserrat tracking-[0.16em] uppercase transition-colors"
      >
        <span>Google Cal</span>
      </a>
    </div>
  );
};
