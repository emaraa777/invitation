import React, { useEffect, useRef, useState } from 'react';
import { invitation } from '../config/invitation';
import { CallaLily } from './CallaLily';

export const FinalSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setInView(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <footer
      id="final-signature-section"
      ref={containerRef}
      className="w-full max-w-lg mx-auto px-4 pt-16 pb-24 text-center border-t border-[#EAE2D7]"
    >
      {/* Tiny floral divider */}
      <div className="flex items-center justify-center gap-3 mb-8">
        <span className="w-12 h-px bg-[#D6CABE]" />
        <CallaLily width={24} height={36} animate={false} />
        <span className="w-12 h-px bg-[#D6CABE]" />
      </div>

      {/* Gentle reveal for Ahmed & Rana */}
      <div
        className="transition-all duration-800 ease-out"
        style={{
          opacity: inView ? 1 : 0,
          transform: inView ? 'translateY(0)' : 'translateY(12px)',
        }}
      >
        <h2 className="font-script text-4xl sm:text-5xl md:text-6xl text-[#2E2822]">
          {invitation.groom} & {invitation.bride}
        </h2>
      </div>

      {/* Date & Time */}
      <div className="mt-4 flex items-center justify-center gap-2 text-xs sm:text-sm font-sans-montserrat tracking-[0.24em] text-[#7A6E62] uppercase">
        <span>24 · 09 · 2026</span>
        <span>•</span>
        <span>7:00 PM</span>
      </div>

      {/* Final closing phrase */}
      <p className="font-serif-cormorant italic text-lg sm:text-xl text-[#52483E] mt-6 max-w-xs mx-auto leading-relaxed">
        With love,
        <br />
        we can’t wait to celebrate with you.
      </p>

      {/* Intimate copyright / stationery credit */}
      <div className="mt-14 text-[10px] tracking-[0.2em] uppercase font-sans-montserrat text-[#A89D91]">
        Levels Cafe · Mansoura, Egypt
      </div>
    </footer>
  );
};
