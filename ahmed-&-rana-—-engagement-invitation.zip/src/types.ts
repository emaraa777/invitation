export interface InvitationConfig {
  groom: string;
  bride: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  timezone: string;
  venue: string;
  city: string;
  country: string;
  mapQuery: string;
}

export interface CountdownTime {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
}

export type RsvpChoice = 'attending_white_heart' | 'attending_smirk' | null;
