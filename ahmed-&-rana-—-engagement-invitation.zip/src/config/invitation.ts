import { InvitationConfig } from '../types';

/**
 * Central event configuration for Ahmed & Rana's engagement ceremony.
 * Update these fields to easily adjust names, dates, times, locations, or music.
 */
export const invitation: InvitationConfig = {
  groom: "Ahmed",
  bride: "Rana",

  date: "2026-09-24",
  time: "19:00",
  timezone: "Africa/Cairo",

  venue: "Levels Cafe",
  city: "Mansoura",
  country: "Egypt",

  mapQuery: "Levels Cafe, Mansoura, Egypt"
};
