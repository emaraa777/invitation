import React, { useState, useRef } from 'react';
import { invitation } from './config/invitation';
import { Envelope } from './components/Envelope';
import { Announcement } from './components/Announcement';
import { EventDetails } from './components/EventDetails';
import { Countdown } from './components/Countdown';
import { CalendarAction } from './components/CalendarAction';
import { PersonalMessage } from './components/PersonalMessage';
import { RsvpSection } from './components/RsvpSection';
import { FinalSection } from './components/FinalSection';

export default function App() {
  const [isOpened, setIsOpened] = useState(false);
  const storyRef = useRef<HTMLDivElement>(null);

  const handleEnvelopeOpenComplete = () => {
    setIsOpened(true);
    // Smoothly scroll down to the announcement after envelope card emerges
    setTimeout(() => {
      storyRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 250);
  };

  return (
    <div className="min-h-screen paper-texture text-[#3D362F] flex flex-col items-center justify-between relative selection:bg-[#EAE0D3] selection:text-[#2E2822]">
      {/* SCREEN 1: INTRO SECTION */}
      <header className="w-full min-h-[92vh] flex flex-col items-center justify-center px-4 py-12 relative">
        {/* Soft Vignette Top Accent */}
        <div className="absolute top-0 inset-x-0 h-24 bg-gradient-to-b from-[#F2EAE0]/50 to-transparent pointer-events-none" />

        <div className="w-full max-w-lg mx-auto text-center flex flex-col items-center">
          {/* "A LITTLE INVITATION FOR YOU" */}
          <p className="text-[10px] sm:text-[11px] tracking-[0.32em] uppercase text-[#8A7E72] font-sans-montserrat font-medium mb-4">
            A little invitation for you
          </p>

          {/* Ahmed & Rana Header */}
          <h1 className="font-script text-5xl sm:text-6xl md:text-7xl text-[#2E2822] mb-10 leading-tight">
            {invitation.groom} & {invitation.bride}
          </h1>

          {/* Redesigned Premium Envelope */}
          <div className="w-full my-2">
            <Envelope onOpenComplete={handleEnvelopeOpenComplete} />
          </div>
        </div>
      </header>

      {/* CONTINUOUS STORY (Unfolds after opening envelope) */}
      <main
        id="invitation-story"
        ref={storyRef}
        className={`w-full max-w-2xl mx-auto flex flex-col items-center transition-all duration-1000 ${
          isOpened
            ? 'opacity-100 translate-y-0 pointer-events-auto'
            : 'opacity-0 translate-y-12 pointer-events-none'
        }`}
      >
        {/* 1. Announcement Section */}
        <Announcement isVisible={isOpened} />

        {/* 2. Date, Time & Venue Details */}
        <EventDetails />

        {/* 3. Countdown */}
        <Countdown />

        {/* 4. Add to Calendar */}
        <CalendarAction />

        {/* 5. Personal Message */}
        <PersonalMessage />

        {/* 6. Interactive RSVP Moment */}
        <RsvpSection />

        {/* 7. Final Signature & Date */}
        <FinalSection />
      </main>
    </div>
  );
}
